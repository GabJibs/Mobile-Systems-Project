
package edu.sti.flashcardssgb;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;



public class MainActivity extends AppCompatActivity {


    private TextView flashcardTextView, cardCountTextView;
    private EditText questionEditText, answerEditText;
    private Button nextButton, saveButton;
    private ArrayList<String[]> flashcards = new ArrayList<>();
    private int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });

        flashcardTextView = findViewById(R.id.flashcard_text_view);
        cardCountTextView = findViewById(R.id.card_count_text_view);
        questionEditText = findViewById(R.id.edit_text_question);
        answerEditText = findViewById(R.id.edit_text_answer);
        nextButton = findViewById(R.id.next_button);
        saveButton = findViewById(R.id.save_button);

        saveButton.setOnClickListener(v -> saveFlashcard());
        nextButton.setOnClickListener(v -> showNextFlashcard());
    }
    private void saveFlashcard() {
        String question = questionEditText.getText().toString();
        String answer = answerEditText.getText().toString();

        if (!question.isEmpty() && !answer.isEmpty()) {
            flashcards.add(new String[]{question, answer});
            updateCardCount();
            questionEditText.setText("");
            answerEditText.setText("");
            flashcardTextView.setText("Card Saved! Add another one.");
        }
    }

    private void showNextFlashcard() {
        if (flashcards.size() > 0) {
            currentIndex = (currentIndex + 1) % flashcards.size();
            flashcardTextView.setText(flashcards.get(currentIndex)[0]);
        } else {
            flashcardTextView.setText("No cards available!");
        }
    }

    private void updateCardCount() {
        cardCountTextView.setText("Cards: " + flashcards.size());
        }
}